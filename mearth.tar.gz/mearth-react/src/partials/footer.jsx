import React from "react";
import '../assets/css/footer.css';

class Footer extends React.Component {
    render() {
        return(
            <div className="foot-main">
                <p>footer</p>
            </div>
        );
    }
}

export default Footer;